package pageObjects;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class DesafioPageObjects {

	private WebDriver driver;

	public DesafioPageObjects (WebDriver driver){
		this.driver = driver;
	}
	

	public WebElement getBuscaButton(){
		WebElement element = (new WebDriverWait(driver, 30))
				.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='ubermenu-nav-main-6-primary' and @class='ubermenu-nav']/li[6] [not (@id='menu-item-2557')]/div/a")));
		return element;
	}
	
	public WebElement getPesquisarTextField(){
		WebElement element = (new WebDriverWait(driver, 30))
				.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='ubermenu-nav-main-6-primary' and @class='ubermenu-nav']/li[6] [not (@id='menu-item-2557')]/ul/li/div/form")));
		return element;
	}
	
	public WebElement getConfirmarPesquisaButton(){
		WebElement element = (new WebDriverWait(driver, 30))
				.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='ubermenu-nav-main-6-primary' and @class='ubermenu-nav']/li[6] [not (@id='menu-item-2557')]/ul/li/div/form/input[2]")));
		return element;
	}
	
	public WebElement getVejaMaisButton(){
		WebElement element = (new WebDriverWait(driver, 30))
				.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("#fl-post-2759 > div > a")));
		return element;
	}
	
	public WebElement getQueroAdquirirText(){
		WebElement element = (new WebDriverWait(driver, 30))
				.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[text()='Quero adquirir, como devo fazer?']")));
		return element;
	}	

}
