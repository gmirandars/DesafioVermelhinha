package testCases;

import org.openqa.selenium.WebDriver;

import PageTasks.DesafioTask;
import Utils.abrirNavegadores;

public class DesafioTestCase {   
	
	 public static void main(String[] args){
		
		 WebDriver driver = abrirNavegadores.chromeDriver();
		 DesafioTask pesquisa = new DesafioTask(driver) ;
		try{	
		 driver.get("http://site.getnet.com.br/");
		 driver.manage().window().maximize();
		 pesquisa.BuscaVermelhinha();
		}catch (Exception e){
			 System.out.println(e);
		}finally{
			driver.close();			
		}
	 }
	
	
	

}
