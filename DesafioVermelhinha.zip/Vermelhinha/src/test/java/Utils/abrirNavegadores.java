package Utils;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

public class abrirNavegadores {
	// Abrir Chrome
		public static WebDriver chromeDriver() {
			ChromeOptions options = new ChromeOptions();
			options.addArguments("chrome.switches", "--disable-extensions");

			// argumentos para entrar no chrome com pt-br
			options.addArguments("--allow-running-insecure-content");
			options.addArguments("--lang=pt-br");

			System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir") + "/drivers/chromedriver.exe");
			return new ChromeDriver(options);
		}

		//Abrir Internet Explorer
		public static WebDriver internetExplorerDriver() {
			System.setProperty("webdriver.ie.driver",
					System.getProperty("user.dir") + "/drivers/IEDriverServer.exe");
//			DesiredCapabilities caps = DesiredCapabilities.internetExplorer();

//			caps.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS,true);

			return new InternetExplorerDriver(); 		
		}
		
		//Abrir FireFox
			public static WebDriver fireFoxDriver() {
				System.setProperty("webdriver.gecko.driver",
						System.getProperty("user.dir") + "/drivers/IEDriverServer.exe");
				return new FirefoxDriver();
			}
}
