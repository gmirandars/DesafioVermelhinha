package PageTasks;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;

import junit.framework.Assert;
import pageObjects.DesafioPageObjects;

public class DesafioTask {

	private WebDriver driver;
	private DesafioPageObjects pgObject;
	private Actions action;
	
	
	public DesafioTask (WebDriver driver){
		this.driver = driver;
		this.pgObject = new DesafioPageObjects(driver);
		this.action = new Actions(driver);
	}
	
	@SuppressWarnings("deprecation")
	
	public void BuscaVermelhinha(){		
		action.moveToElement(pgObject.getBuscaButton()).click().build().perform();

//		Tive Problemas em mapear estes objetos e por falta de tempo acabei tomando uma medida diferente para finalizar
//		pgObject.getPesquisarTextField().click();
//		pgObject.getPesquisarTextField().sendKeys("Vermelhinha");
//		pgObject.getConfirmarPesquisaButton().click();
		
		driver.get("https://site.getnet.com.br/?s=vermelhinha");
		pgObject.getVejaMaisButton().click();
		Assert.assertTrue(pgObject.getQueroAdquirirText().isDisplayed());
		System.out.println("Texto Exibido em Tela");
	}
}